
import afficheur.Ecran;
import java.awt.Color;

/**
  * Exemple d'utilisation de la classe Ecran.
  */
class ExempleEcran {

	public static void main(String[] args) {
		// Construire un écran

		// Dessiner un point vert de coordonnées (1, 2)

		// Dessiner un segment rouge d'extrémités (6, 2) et (11, 9)

		// Dessiner un cercle jaune de centre (4, 3) et rayon 2.5

		// Dessiner le texte "Premier dessin" en bleu à la position (1, -2)
	}

}
