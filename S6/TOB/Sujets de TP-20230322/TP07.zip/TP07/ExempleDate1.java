// Que penser du programme suivant ?
public class ExempleDate1 {
	public static void main (String args []) {
		// Construire les dates
		Date d1 = new Date(20, 5, 1989);
		Date d2 = new Date(13, 2, 1993);
		Date d3 = new Date(31, 6, 2001);

		// Afficher les dates
		System.out.println("d1 = " + d1);
		System.out.println("d2 = " + d2);
		System.out.println("d3 = " + d3);
	}
}
