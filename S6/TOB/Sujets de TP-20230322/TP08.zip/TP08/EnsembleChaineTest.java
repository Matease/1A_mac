/**
 * Classe de test pour EnsembleChaine.
 */
public class EnsembleChaineTest extends EnsembleTestAbstrait {

	protected Ensemble nouvelEnsemble(int capacite) {
		return new EnsembleChaine();
	}

}
