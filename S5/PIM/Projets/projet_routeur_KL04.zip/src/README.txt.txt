# Manuel d'utilisation du programme routeur-simple

## 1. Compiler

Compiler le projet avec 

```bash
gnatmake routeur.adb
```

## 2. Lancer

```bash
./routeur
```